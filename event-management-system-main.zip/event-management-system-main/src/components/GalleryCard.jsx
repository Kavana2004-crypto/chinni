import React from 'react'

export default function GalleryCard() {
  return (
                    
    <div>GalleryCard</div>
  )
}
